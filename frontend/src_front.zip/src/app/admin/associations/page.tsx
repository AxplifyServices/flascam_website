'use client';

import {
  ChangeEvent,
  FormEvent,
  ReactNode,
  RefObject,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import Link from 'next/link';

import dynamic from 'next/dynamic';

import {
  Building2,
  CheckCircle2,
  Eye,
  Loader2,
  MapPin,
  Plus,
  Save,
  Search,
  Upload,
  UserRound,
  X,
} from 'lucide-react';

import {
  createAdminAssociation,
  getAdminAssociation,
  getAdminAssociations,
  updateAdminAssociation,
  updateAdminAssociationStatus,
  uploadAdminImage,
} from '@/lib/associations-api';

import type {
  AssociationDetail,
  AssociationFormState,
  AssociationLeaderRole,
  AssociationSummary,
} from '@/types/associations';

const AssociationMapPositionEditor =
  dynamic(
    () =>
      import(
        '@/components/admin/association-map-position-editor'
      ).then(
        (module) =>
          module.AssociationMapPositionEditor,
      ),
    {
      ssr: false,

      loading: () => (
        <div className="grid h-[500px] place-items-center rounded-2xl border border-[var(--flascam-border)] bg-[#f8fbfd]">
          <p className="text-sm font-bold text-[var(--flascam-slate)]">
            Chargement de la carte du Maroc…
          </p>
        </div>
      ),
    },
  );

function createEmptyLeaders():
  AssociationFormState['leaders'] {
  return [
    {
      role: 'PRESIDENT',
      fullName: '',
      photoMediaAssetId: '',
      photoUrl: '',
      biography: '',
      message: '',
      isPublished: true,
      displayOrder: '0',
    },
    {
      role: 'SECRETARY_GENERAL',
      fullName: '',
      photoMediaAssetId: '',
      photoUrl: '',
      biography: '',
      message: '',
      isPublished: true,
      displayOrder: '1',
    },
  ];
}  

const emptyForm: AssociationFormState = {
  name: '',
  slug: '',
  acronym: '',
  region: '',
  city: '',

  latitude: '',
  longitude: '',
  mapIsVisible: true,

  memberCount: '',
  affiliatedSinceYear: '',
  logoMediaAssetId: '',
  coverImageUrl: '',
  logoText: '',
  presentation: '',
  address: '',
  phone: '',
  email: '',
  websiteUrl: '',
  facebookUrl: '',
  instagramUrl: '',
  linkedinUrl: '',
  youtubeUrl: '',
  isFeatured: false,
  displayOrder: '0',
seoTitle: '',
seoDescription: '',

leaders: createEmptyLeaders(),

adminEmail: '',
adminFirstName: '',
adminLastName: '',
adminPassword: '',
};

function createEmptyForm():
  AssociationFormState {
  return {
    ...emptyForm,
    leaders: createEmptyLeaders(),
  };
}

const statusLabels: Record<string, string> = {
  DRAFT: 'Brouillon',
  SUBMITTED: 'En validation',
  PUBLISHED: 'Publié',
  ARCHIVED: 'Archivé',
};

function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function leadersFromAssociation(
  association:
    | AssociationDetail
    | AssociationSummary,
): AssociationFormState['leaders'] {
  if (!('leaders' in association)) {
    return createEmptyLeaders();
  }

  const leaders =
    association.leaders ?? [];

  const president =
    leaders.find(
      (leader) =>
        leader.role === 'PRESIDENT',
    );

  const secretaryGeneral =
    leaders.find(
      (leader) =>
        leader.role ===
        'SECRETARY_GENERAL',
    );

  return [
    {
      role: 'PRESIDENT',

      fullName:
        president?.fullName ?? '',

      photoMediaAssetId:
        president?.photoMediaAssetId ??
        '',

      photoUrl:
        president?.photoUrl ?? '',

      biography:
        president?.biography ?? '',

      message:
        president?.message ?? '',

      isPublished:
        president?.isPublished ?? true,

      displayOrder:
        String(
          president?.displayOrder ?? 0,
        ),
    },

    {
      role: 'SECRETARY_GENERAL',

      fullName:
        secretaryGeneral?.fullName ??
        '',

      photoMediaAssetId:
        secretaryGeneral
          ?.photoMediaAssetId ?? '',

      photoUrl:
        secretaryGeneral?.photoUrl ??
        '',

      biography:
        secretaryGeneral?.biography ??
        '',

      message: '',

      isPublished:
        secretaryGeneral?.isPublished ??
        true,

      displayOrder:
        String(
          secretaryGeneral
            ?.displayOrder ?? 1,
        ),
    },
  ];
}

function formFromAssociation(
  association: AssociationDetail | AssociationSummary,
): AssociationFormState {
  return {
    name: association.name ?? '',
    slug: association.slug ?? '',
    acronym: association.acronym ?? '',
    region:
      association.region ?? '',

    city:
      association.city ?? '',

latitude:
  association.latitude === null ||
  association.latitude === undefined
    ? ''
    : String(
        association.latitude,
      ),

longitude:
  association.longitude === null ||
  association.longitude === undefined
    ? ''
    : String(
        association.longitude,
      ),

    mapIsVisible:
      association.mapIsVisible ??
      true,

    memberCount:
      association.memberCount === null ||
      association.memberCount === undefined
        ? ''
        : String(association.memberCount),
    affiliatedSinceYear: association.affiliatedSinceYear
      ? String(association.affiliatedSinceYear)
      : '',
    logoMediaAssetId:
      'logoMediaAssetId' in association
        ? String(association.logoMediaAssetId ?? '')
        : '',

coverImageUrl:
  association.coverImageUrl ?? '',

    logoText: association.logoText ?? '',
    presentation:
      'presentation' in association
        ? association.presentation ?? ''
        : '',
    address:
      'address' in association
        ? association.address ?? ''
        : '',
    phone:
      'phone' in association
        ? association.phone ?? ''
        : '',
    email:
      'email' in association
        ? association.email ?? ''
        : '',
    websiteUrl:
      'websiteUrl' in association
        ? association.websiteUrl ?? ''
        : '',
    facebookUrl:
      'facebookUrl' in association
        ? association.facebookUrl ?? ''
        : '',
    instagramUrl:
      'instagramUrl' in association
        ? association.instagramUrl ?? ''
        : '',
    linkedinUrl:
      'linkedinUrl' in association
        ? association.linkedinUrl ?? ''
        : '',
    youtubeUrl:
      'youtubeUrl' in association
        ? association.youtubeUrl ?? ''
        : '',
    isFeatured: association.isFeatured ?? false,
    displayOrder:
      association.displayOrder === null ||
      association.displayOrder === undefined
        ? '0'
        : String(association.displayOrder),
seoTitle:
  association.seoTitle ?? '',

seoDescription:
  association.seoDescription ?? '',

leaders:
  leadersFromAssociation(
    association,
  ),

adminEmail:
  'adminAccount' in association
    ? association.adminAccount?.email ?? ''
    : '',
    adminFirstName:
      'adminAccount' in association
        ? association.adminAccount?.firstName ?? ''
        : '',
    adminLastName:
      'adminAccount' in association
        ? association.adminAccount?.lastName ?? ''
        : '',
    adminPassword: '',
  };
}

export default function AdminAssociationsPage() {
  const [
    associations,
    setAssociations,
  ] = useState<AssociationSummary[]>([]);

  const [
    selected,
    setSelected,
  ] = useState<AssociationDetail | null>(null);

const [
  form,
  setForm,
] =
  useState<AssociationFormState>(
    createEmptyForm,
  );

  const [
    modalOpen,
    setModalOpen,
  ] = useState(false);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    loadingDetails,
    setLoadingDetails,
  ] = useState(false);

  const [
    saving,
    setSaving,
  ] = useState(false);

  const [
    logoUploading,
    setLogoUploading,
  ] = useState(false);

  const [
    logoPreviewUrl,
    setLogoPreviewUrl,
  ] = useState('');

const [
  coverUploading,
  setCoverUploading,
] = useState(false);

const [
  coverPreviewUrl,
  setCoverPreviewUrl,
] = useState('');  

const [
  uploadingLeaderRole,
  setUploadingLeaderRole,
] =
  useState<AssociationLeaderRole | null>(
    null,
  );

  const [
    pageError,
    setPageError,
  ] = useState('');

  const [
    modalError,
    setModalError,
  ] = useState('');

  const modalScrollRef =
    useRef<HTMLDivElement | null>(null);

  const [
    success,
    setSuccess,
  ] = useState('');

  const [
    query,
    setQuery,
  ] = useState('');

  const filtered = useMemo(() => {
    const searchValue =
      query.trim().toLowerCase();

    if (!searchValue) {
      return associations;
    }

    return associations.filter((association) =>
      [
        association.name,
        association.region,
        association.city,
        association.status,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()
        .includes(searchValue),
    );
  }, [associations, query]);

  useEffect(() => {
    void load();
  }, []);

  async function load() {
    setLoading(true);
    setPageError('');

    try {
      const data = await getAdminAssociations();
      setAssociations(data);
    } catch (caughtError) {
      setPageError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Impossible de charger les associations.',
      );
    } finally {
      setLoading(false);
    }
  }

  function showModalError(message: string) {
    setModalError(message);

    requestAnimationFrame(() => {
      modalScrollRef.current?.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
    });
  }

  function updateField(
    field: keyof AssociationFormState,
    value: string | boolean,
  ) {
    setForm((current) => ({
      ...current,
      [field]: value,
      ...(field === 'name' && !selected
        ? {
            slug: slugify(String(value)),
            logoText: String(value)
              .slice(0, 2)
              .toUpperCase(),
          }
        : {}),
    }));
  }

  function updateLeaderField(
  role: AssociationLeaderRole,
  field:
    | 'fullName'
    | 'biography'
    | 'message',
  value: string,
) {
  setForm((current) => ({
    ...current,

    leaders:
      current.leaders.map(
        (leader) =>
          leader.role === role
            ? {
                ...leader,
                [field]: value,
              }
            : leader,
      ),
  }));

  setModalError('');
  setSuccess('');
}

function updateLeaderPublished(
  role: AssociationLeaderRole,
  isPublished: boolean,
) {
  setForm((current) => ({
    ...current,

    leaders:
      current.leaders.map(
        (leader) =>
          leader.role === role
            ? {
                ...leader,
                isPublished,
              }
            : leader,
      ),
  }));

  setModalError('');
  setSuccess('');
}

function removeLeaderPhoto(
  role: AssociationLeaderRole,
) {
  setForm((current) => ({
    ...current,

    leaders:
      current.leaders.map(
        (leader) =>
          leader.role === role
            ? {
                ...leader,
                photoMediaAssetId: '',
                photoUrl: '',
              }
            : leader,
      ),
  }));

  setModalError('');

  setSuccess(
    'La photo sera retirée après l’enregistrement de l’association.',
  );
}

  function startCreate() {
    setSelected(null);
setForm(
  createEmptyForm(),
);
    setLogoPreviewUrl('');
    setCoverPreviewUrl('');
setUploadingLeaderRole(null);
    setPageError('');
    setModalError('');
    setSuccess('');
    setModalOpen(true);
  }

  async function startEdit(
    association: AssociationSummary,
  ) {
    setPageError('');
    setModalError('');
    setSuccess('');
    setLoadingDetails(true);

    try {
      const detail =
        await getAdminAssociation(
          association.id,
        );

      setSelected(detail);
      setForm(formFromAssociation(detail));
      setLogoPreviewUrl(detail.logoUrl ?? '');
      setCoverPreviewUrl(detail.coverImageUrl ?? '');
      setModalOpen(true);
    } catch (caughtError) {
      setPageError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Impossible de charger cette association.',
      );
    } finally {
      setLoadingDetails(false);
    }
  }

function closeModal() {
  if (
    saving ||
    logoUploading ||
    coverUploading ||
    uploadingLeaderRole !== null
  ) {
    return;
  }

  setModalOpen(false);
  setSelected(null);

  setForm(
    createEmptyForm(),
  );

  setLogoPreviewUrl('');
  setCoverPreviewUrl('');
  setModalError('');
  setSuccess('');
  setUploadingLeaderRole(null);
}

  async function handleLogoUpload(file?: File) {
    if (!file) {
      return;
    }

    setLogoUploading(true);
    setModalError('');
    setSuccess('');

    try {
      const uploaded =
        await uploadAdminImage(file);

      setForm((current) => ({
        ...current,
        logoMediaAssetId: uploaded.id,
      }));

      setLogoPreviewUrl(uploaded.url);

      setSuccess(
        'Logo importé. Pense à enregistrer l’association pour appliquer le changement.',
      );
    } catch (caughtError) {
      showModalError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Import du logo impossible.',
      );
    } finally {
      setLogoUploading(false);
    }
  }

async function handleCoverUpload(file?: File) {
  if (!file) {
    return;
  }

  setCoverUploading(true);
  setModalError('');
  setSuccess('');

  try {
    const uploaded =
      await uploadAdminImage(file);

    setForm((current) => ({
      ...current,
      coverImageUrl: uploaded.url,
    }));

    setCoverPreviewUrl(uploaded.url);

    setSuccess(
      'Photo de couverture importée. Enregistre l’association pour appliquer le changement.',
    );
  } catch (caughtError) {
    showModalError(
      caughtError instanceof Error
        ? caughtError.message
        : 'Import de la couverture impossible.',
    );
  } finally {
    setCoverUploading(false);
  }
}  

async function handleLeaderPhotoUpload(
  role: AssociationLeaderRole,
  event: ChangeEvent<HTMLInputElement>,
) {
  const file =
    event.target.files?.[0];

  event.target.value = '';

  if (!file) {
    return;
  }

  setUploadingLeaderRole(role);
  setModalError('');
  setSuccess('');

  try {
    const uploaded =
      await uploadAdminImage(file);

    setForm((current) => ({
      ...current,

      leaders:
        current.leaders.map(
          (leader) =>
            leader.role === role
              ? {
                  ...leader,

                  photoMediaAssetId:
                    uploaded.id,

                  photoUrl:
                    uploaded.url,
                }
              : leader,
        ),
    }));

    setSuccess(
      'Photo importée. Enregistrez l’association pour confirmer la modification.',
    );
  } catch (caughtError) {
    showModalError(
      caughtError instanceof Error
        ? caughtError.message
        : 'Import de la photo impossible.',
    );
  } finally {
    setUploadingLeaderRole(null);
  }
}

  async function submit(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();

const hasLatitude =
  form.latitude.trim() !== '';

const hasLongitude =
  form.longitude.trim() !== '';

if (
  hasLatitude !==
  hasLongitude
) {
  showModalError(
    'La latitude et la longitude doivent être renseignées ensemble.',
  );

  return;
}

if (
  hasLatitude &&
  hasLongitude
) {
  const latitude =
    Number(
      form.latitude,
    );

  const longitude =
    Number(
      form.longitude,
    );

  if (
    !Number.isFinite(
      latitude,
    ) ||
    latitude < -90 ||
    latitude > 90
  ) {
    showModalError(
      'La latitude doit être comprise entre -90 et 90.',
    );

    return;
  }

  if (
    !Number.isFinite(
      longitude,
    ) ||
    longitude < -180 ||
    longitude > 180
  ) {
    showModalError(
      'La longitude doit être comprise entre -180 et 180.',
    );

    return;
  }
}

if (
  form.mapIsVisible &&
  (
    !hasLatitude ||
    !hasLongitude
  )
) {
  showModalError(
    'Placez l’association sur la carte ou désactivez son affichage public.',
  );

  return;
}

const president =
  form.leaders.find(
    (leader) =>
      leader.role === 'PRESIDENT',
  );

const secretaryGeneral =
  form.leaders.find(
    (leader) =>
      leader.role ===
      'SECRETARY_GENERAL',
  );

if (
  president?.biography.trim() &&
  !president.fullName.trim()
) {
  showModalError(
    'Renseignez le nom du président avant d’ajouter sa biographie.',
  );

  return;
}

if (
  president?.message.trim() &&
  !president.fullName.trim()
) {
  showModalError(
    'Renseignez le nom du président avant d’ajouter son mot.',
  );

  return;
}

if (
  president?.photoMediaAssetId &&
  !president.fullName.trim()
) {
  showModalError(
    'Renseignez le nom du président avant d’ajouter sa photo.',
  );

  return;
}

if (
  secretaryGeneral?.biography.trim() &&
  !secretaryGeneral.fullName.trim()
) {
  showModalError(
    'Renseignez le nom du secrétaire général avant d’ajouter sa biographie.',
  );

  return;
}

if (
  secretaryGeneral?.photoMediaAssetId &&
  !secretaryGeneral.fullName.trim()
) {
  showModalError(
    'Renseignez le nom du secrétaire général avant d’ajouter sa photo.',
  );

  return;
}



    setSaving(true);
    setModalError('');
    setSuccess('');

    try {
      const updated = selected
        ? await updateAdminAssociation(
            selected.id,
            form,
          )
        : await createAdminAssociation(form);

      setSuccess(
        selected
          ? 'Association modifiée.'
          : 'Association créée.',
      );

      setSelected(updated);
      setForm(formFromAssociation(updated));
      setLogoPreviewUrl(updated.logoUrl ?? '');

setCoverPreviewUrl(
  updated.coverImageUrl ?? '',
);      

      await load();
      setModalOpen(false);
    } catch (caughtError) {
      showModalError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Enregistrement impossible.',
      );
    } finally {
      setSaving(false);
    }
  }

  async function changeStatus(
    status:
      | 'DRAFT'
      | 'SUBMITTED'
      | 'PUBLISHED'
      | 'ARCHIVED',
  ) {
    if (!selected) {
      return;
    }

    setSaving(true);
    setModalError('');
    setSuccess('');

    try {
      await updateAdminAssociationStatus(
        selected.id,
        status,
      );

      const refreshed =
        await getAdminAssociation(
          selected.id,
        );

      setSelected(refreshed);
      setForm(formFromAssociation(refreshed));
      setLogoPreviewUrl(refreshed.logoUrl ?? '');

      await load();

      setSuccess(
        `Statut mis à jour : ${statusLabels[status]}.`,
      );
    } catch (caughtError) {
      showModalError(
        caughtError instanceof Error
          ? caughtError.message
          : 'Changement de statut impossible.',
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto max-w-7xl">
      <header className="rounded-[2rem] border border-[var(--flascam-border)] bg-white p-5 shadow-sm sm:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.18em] text-[var(--flascam-blue)]">
              <Building2 size={16} />
              Associations régionales
            </p>

            <h1 className="mt-3 text-2xl font-extrabold tracking-[-0.03em] text-slate-950 sm:text-3xl">
              Gestion des associations
            </h1>

            <p className="mt-2 max-w-3xl text-sm leading-6 text-[var(--flascam-slate)]">
              Créez les associations régionales, préparez leurs pages publiques
              et publiez uniquement les fiches validées.
            </p>
          </div>

          <button
            type="button"
            onClick={startCreate}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[var(--flascam-blue)] px-5 text-sm font-bold text-white transition hover:bg-[var(--flascam-blue-dark)]"
          >
            <Plus size={18} />
            Nouvelle association
          </button>
        </div>
      </header>

      {pageError && (
        <p className="mt-5 rounded-xl bg-red-50 p-4 text-sm font-medium text-red-800">
          {pageError}
        </p>
      )}

      {success && (
        <p className="mt-5 rounded-xl bg-emerald-50 p-4 text-sm font-medium text-emerald-800">
          {success}
        </p>
      )}

      <section className="mt-6 rounded-[1.5rem] border border-[var(--flascam-border)] bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-lg font-extrabold text-slate-950">
              Liste des associations
            </h2>

            <p className="mt-1 text-sm text-[var(--flascam-slate)]">
              Cliquez sur une association pour ouvrir sa fiche en modification.
            </p>
          </div>

          <label className="relative block w-full md:max-w-sm">
            <Search
              size={17}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--flascam-slate)]"
            />

            <input
              value={query}
              onChange={(event) =>
                setQuery(event.target.value)
              }
              placeholder="Rechercher..."
              className="h-11 w-full rounded-xl border border-[var(--flascam-border)] pl-10 pr-4 text-sm outline-none focus:border-[var(--flascam-blue)]"
            />
          </label>
        </div>

        {loading || loadingDetails ? (
          <div className="grid min-h-64 place-items-center">
            <Loader2 className="animate-spin text-[var(--flascam-blue)]" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-5 rounded-2xl border border-dashed border-[var(--flascam-border)] bg-[var(--ivory)] p-8 text-center">
            <Building2
              size={34}
              className="mx-auto text-[var(--flascam-blue)]"
            />

            <h3 className="mt-4 text-xl font-extrabold text-slate-950">
              Aucune association trouvée
            </h3>

            <p className="mt-2 text-sm text-[var(--flascam-slate)]">
              Créez une première association régionale pour alimenter le site public.
            </p>
          </div>
        ) : (
          <div className="mt-5 overflow-hidden rounded-2xl border border-[var(--flascam-border)]">
            <div className="hidden grid-cols-[1.5fr_1fr_9rem_9rem] gap-4 bg-slate-50 px-5 py-3 text-xs font-extrabold uppercase tracking-wide text-[var(--flascam-slate)] lg:grid">
              <span>Association</span>
              <span>Région</span>
              <span>Statut</span>
              <span>Action</span>
            </div>

            <div className="divide-y divide-[var(--flascam-border)]">
              {filtered.map((association) => (
                <button
                  key={association.id}
                  type="button"
                  onClick={() =>
                    void startEdit(association)
                  }
                  className="grid w-full gap-3 px-5 py-4 text-left transition hover:bg-[#f8fbff] lg:grid-cols-[1.5fr_1fr_9rem_9rem] lg:items-center"
                >
                  <div>
                    <p className="font-extrabold text-slate-950">
                      {association.name}
                    </p>

                    <p className="mt-1 text-xs text-[var(--flascam-slate)]">
                      /associations/{association.slug}
                    </p>
                  </div>

                  <p className="flex items-center gap-2 text-sm text-[var(--flascam-slate)]">
                    <MapPin size={15} />
                    {association.city
                      ? `${association.city} · ${association.region}`
                      : association.region}
                  </p>

                  

                  <span className="w-fit rounded-full bg-slate-100 px-3 py-1 text-xs font-extrabold text-slate-700">
                    {
                      statusLabels[
                        association.status ?? 'DRAFT'
                      ] ?? association.status
                    }
                  </span>

                  <span className="text-sm font-bold text-[var(--flascam-blue)]">
                    Modifier
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </section>

      {modalOpen && (
        <Modal
          title={
            selected
              ? 'Modifier l’association'
              : 'Créer une association'
          }
          onClose={closeModal}
          scrollRef={modalScrollRef}
        >
          <form
            onSubmit={submit}
            className="space-y-7"
          >
            {modalError && (
              <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-medium leading-6 text-red-800">
                {modalError}
              </div>
            )}

            {selected && (
              <div className="rounded-2xl bg-[#f8fbff] p-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <p className="text-sm font-bold text-slate-950">
                    Statut actuel :{' '}
                    {
                      statusLabels[
                        selected.status ?? 'DRAFT'
                      ] ?? selected.status
                    }
                  </p>

                  {selected.slug && (
                    <Link
                      href={`/associations/${selected.slug}`}
                      target="_blank"
                      className="inline-flex h-9 items-center justify-center gap-2 rounded-xl border border-[var(--flascam-border)] bg-white px-3 text-xs font-bold text-slate-700 hover:border-[var(--flascam-blue)] hover:text-[var(--flascam-blue)]"
                    >
                      <Eye size={15} />
                      Voir la page
                    </Link>
                  )}
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <StatusButton
                    label="Brouillon"
                    onClick={() =>
                      changeStatus('DRAFT')
                    }
                  />

                  <StatusButton
                    label="En validation"
                    onClick={() =>
                      changeStatus('SUBMITTED')
                    }
                  />

                  <StatusButton
                    label="Publier"
                    icon={
                      <CheckCircle2 size={15} />
                    }
                    onClick={() =>
                      changeStatus('PUBLISHED')
                    }
                  />

                  <StatusButton
                    label="Archiver"
                    onClick={() =>
                      changeStatus('ARCHIVED')
                    }
                  />
                </div>
              </div>
            )}

            <FormSection title="Identité">
              <div className="grid gap-5 lg:grid-cols-2">
                <AdminInput
                  label="Nom de l’association"
                  value={form.name}
                  onChange={(value) =>
                    updateField('name', value)
                  }
                  required
                />

                <AdminInput
                  label="Slug URL"
                  value={form.slug}
                  onChange={(value) =>
                    updateField(
                      'slug',
                      slugify(value),
                    )
                  }
                  required
                />

                <AdminInput
                  label="Acronyme"
                  value={form.acronym}
                  onChange={(value) =>
                    updateField('acronym', value)
                  }
                />

                <AdminInput
                  label="Texte logo si pas d’image"
                  value={form.logoText}
                  onChange={(value) =>
                    updateField('logoText', value)
                  }
                  maxLength={12}
                />

                <AdminInput
                  label="Région"
                  value={form.region}
                  onChange={(value) =>
                    updateField('region', value)
                  }
                  required
                />

                <AdminInput
                  label="Ville"
                  value={form.city}
                  onChange={(value) =>
                    updateField('city', value)
                  }
                />



                <AdminInput
                  label="Nombre de loueurs membres"
                  type="number"
                  value={form.memberCount}
                  onChange={(value) =>
                    updateField(
                      'memberCount',
                      value,
                    )
                  }
                />

                <AdminInput
                  label="Année d’affiliation"
                  type="number"
                  value={form.affiliatedSinceYear}
                  onChange={(value) =>
                    updateField(
                      'affiliatedSinceYear',
                      value,
                    )
                  }
                />
              </div>

              <AdminTextarea
                label="Présentation"
                value={form.presentation}
                onChange={(value) =>
                  updateField(
                    'presentation',
                    value,
                  )
                }
              />
            </FormSection>

<FormSection title="Équipe dirigeante">
  <div className="rounded-2xl border border-[#bfdbfe] bg-[#eff6ff] p-5 text-sm leading-7 text-[#1e4f7a]">
    <p className="font-extrabold text-[#07355d]">
      Présentation institutionnelle
    </p>

    <p className="mt-2">
      Ces informations seront affichées sur la page publique
      de l’association. Le mot institutionnel est réservé au
      président.
    </p>
  </div>

  <div className="grid gap-6 xl:grid-cols-2">
    {form.leaders.map(
      (leader) => (
        <AssociationLeaderEditor
          key={leader.role}
          role={leader.role}
          fullName={leader.fullName}
          photoUrl={leader.photoUrl}
          biography={leader.biography}
          message={leader.message}
          isPublished={
            leader.isPublished
          }
          uploading={
            uploadingLeaderRole ===
            leader.role
          }
          onFullNameChange={(value) =>
            updateLeaderField(
              leader.role,
              'fullName',
              value,
            )
          }
          onBiographyChange={(value) =>
            updateLeaderField(
              leader.role,
              'biography',
              value,
            )
          }
          onMessageChange={(value) =>
            updateLeaderField(
              leader.role,
              'message',
              value,
            )
          }
          onPublishedChange={(value) =>
            updateLeaderPublished(
              leader.role,
              value,
            )
          }
          onPhotoChange={(event) =>
            void handleLeaderPhotoUpload(
              leader.role,
              event,
            )
          }
          onPhotoRemove={() =>
            removeLeaderPhoto(
              leader.role,
            )
          }
        />
      ),
    )}
  </div>
</FormSection>            

            <FormSection title="Coordonnées">
              <div className="grid gap-5 lg:grid-cols-2">
                <AdminInput
                  label="Adresse"
                  value={form.address}
                  onChange={(value) =>
                    updateField('address', value)
                  }
                />

                <AdminInput
                  label="Téléphone"
                  value={form.phone}
                  onChange={(value) =>
                    updateField('phone', value)
                  }
                />

                <AdminInput
                  label="E-mail"
                  type="email"
                  value={form.email}
                  onChange={(value) =>
                    updateField('email', value)
                  }
                />

                <AdminInput
                  label="Site web"
                  value={form.websiteUrl}
                  onChange={(value) =>
                    updateField(
                      'websiteUrl',
                      value,
                    )
                  }
                />
              </div>
            </FormSection>

<FormSection title="Localisation sur la carte du Maroc">
  <div className="grid gap-6 xl:grid-cols-[minmax(0,0.8fr)_minmax(440px,1.2fr)] xl:items-start">
    <div className="space-y-5">
      <div className="rounded-2xl border border-[#bfdbfe] bg-[#eff6ff] p-5 text-sm leading-7 text-[#1e4f7a]">
        <p className="font-extrabold text-[#07355d]">
          Position publique de l’association
        </p>

        <p className="mt-2">
          La position définie ici sera utilisée sur la carte interactive de la
          page d’accueil. Cliquez directement sur la carte pour placer le
          marqueur.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <AdminInput
          label="Latitude"
          type="number"
          value={
            form.latitude
          }
          onChange={(value) =>
            updateField(
              'latitude',
              value,
            )
          }
          helper="Exemple Casablanca : 33.573110"
        />

        <AdminInput
          label="Longitude"
          type="number"
          value={
            form.longitude
          }
          onChange={(value) =>
            updateField(
              'longitude',
              value,
            )
          }
          helper="Exemple Casablanca : -7.589843"
        />
      </div>

      <label className="flex items-start gap-3 rounded-xl border border-[var(--flascam-border)] p-4">
        <input
          type="checkbox"
          checked={
            form.mapIsVisible
          }
          onChange={(event) =>
            updateField(
              'mapIsVisible',
              event.target.checked,
            )
          }
          className="mt-1"
        />

        <span>
          <span className="block text-sm font-bold text-slate-800">
            Afficher cette association sur la carte publique
          </span>

          <span className="mt-1 block text-xs leading-5 text-[var(--flascam-slate)]">
            L’association doit être publiée et posséder une latitude et une
            longitude valides.
          </span>
        </span>
      </label>

      {(form.latitude ||
        form.longitude) && (
        <button
          type="button"
          onClick={() => {
            updateField(
              'latitude',
              '',
            );

            updateField(
              'longitude',
              '',
            );
          }}
          className="inline-flex h-11 items-center justify-center rounded-xl border border-red-200 px-4 text-sm font-bold text-red-700 transition hover:bg-red-50"
        >
          Retirer le point de la carte
        </button>
      )}
    </div>

    <AssociationMapPositionEditor
      associationName={
        form.name
      }
      latitude={
        form.latitude
      }
      longitude={
        form.longitude
      }
      disabled={
        saving
      }
      onChange={(
        latitude,
        longitude,
      ) => {
        setForm(
          (
            current,
          ) => ({
            ...current,
            latitude,
            longitude,
          }),
        );
      }}
    />
  </div>
</FormSection>            

            <FormSection title="Réseaux sociaux">
              <div className="grid gap-5 lg:grid-cols-2">
                <AdminInput
                  label="Facebook"
                  value={form.facebookUrl}
                  onChange={(value) =>
                    updateField(
                      'facebookUrl',
                      value,
                    )
                  }
                />

                <AdminInput
                  label="Instagram"
                  value={form.instagramUrl}
                  onChange={(value) =>
                    updateField(
                      'instagramUrl',
                      value,
                    )
                  }
                />

                <AdminInput
                  label="LinkedIn"
                  value={form.linkedinUrl}
                  onChange={(value) =>
                    updateField(
                      'linkedinUrl',
                      value,
                    )
                  }
                />

                <AdminInput
                  label="YouTube"
                  value={form.youtubeUrl}
                  onChange={(value) =>
                    updateField(
                      'youtubeUrl',
                      value,
                    )
                  }
                />
              </div>
            </FormSection>

            <FormSection title="Médias et affichage">
              <div className="grid gap-5 lg:grid-cols-2">
                <div className="rounded-2xl border border-[var(--flascam-border)] p-4">
                  <span className="text-sm font-bold text-slate-800">
                    Logo de l’association
                  </span>

                  <div className="mt-3 flex flex-col gap-4 sm:flex-row sm:items-center">
                    <div className="grid size-24 place-items-center overflow-hidden rounded-2xl bg-[var(--flascam-blue-dark)]">
                      {logoPreviewUrl ? (
                        <img
                          src={logoPreviewUrl}
                          alt="Logo association"
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span className="text-xl font-black text-white">
                          {form.logoText ||
                            form.name
                              .slice(0, 2)
                              .toUpperCase() ||
                            'LO'}
                        </span>
                      )}
                    </div>

                    <div className="flex-1">
                      <label className="inline-flex h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-[var(--flascam-border)] bg-white px-4 text-sm font-bold text-slate-700 transition hover:border-[var(--flascam-blue)] hover:text-[var(--flascam-blue)]">
                        {logoUploading ? (
                          <Loader2
                            size={16}
                            className="animate-spin"
                          />
                        ) : (
                          <Upload size={16} />
                        )}

                        Importer un logo

                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp,image/svg+xml"
                          className="hidden"
                          disabled={logoUploading}
                          onChange={(event) =>
                            void handleLogoUpload(
                              event.target.files?.[0],
                            )
                          }
                        />
                      </label>

                      <p className="mt-2 text-xs leading-5 text-[var(--flascam-slate)]">
                        Formats acceptés : JPG, PNG, WEBP, SVG. Le fichier est stocké dans MinIO.
                      </p>

                      {form.logoMediaAssetId && (
                        <p className="mt-1 text-xs text-slate-400">
                          Média lié : {form.logoMediaAssetId}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

<div className="lg:col-span-2">
  <p className="mb-2 text-sm font-bold text-slate-800">
    Photo de couverture
  </p>

  <div className="overflow-hidden rounded-xl border border-[var(--flascam-border)] bg-[#f5f9fc]">
    <div className="relative h-48">
      {coverPreviewUrl ? (
        <img
          src={coverPreviewUrl}
          alt="Aperçu de la couverture"
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="grid h-full place-items-center bg-gradient-to-br from-[#07355d] via-[#0a487b] to-[#0f5f9f] px-6 text-center text-sm font-bold text-white/75">
          Aucune couverture importée
        </div>
      )}
    </div>

    <div className="flex flex-col gap-3 border-t border-[var(--flascam-border)] bg-white p-4 sm:flex-row sm:items-center">
      <label className="inline-flex h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-[var(--flascam-border)] bg-white px-4 text-sm font-bold text-slate-700 transition hover:border-[var(--flascam-blue)] hover:text-[var(--flascam-blue)]">
        {coverUploading ? (
          <Loader2
            size={16}
            className="animate-spin"
          />
        ) : (
          <Upload size={16} />
        )}

        Importer une couverture

        <input
          type="file"
          accept="image/png,image/jpeg,image/webp"
          className="hidden"
          disabled={coverUploading}
          onChange={(event) =>
            void handleCoverUpload(
              event.target.files?.[0],
            )
          }
        />
      </label>

      {coverPreviewUrl && (
        <button
          type="button"
          onClick={() => {
            setCoverPreviewUrl('');
            updateField(
              'coverImageUrl',
              '',
            );
          }}
          className="inline-flex h-11 items-center justify-center rounded-xl border border-red-200 px-4 text-sm font-bold text-red-700 transition hover:bg-red-50"
        >
          Retirer la couverture
        </button>
      )}
    </div>
  </div>

  <p className="mt-2 text-xs leading-5 text-[var(--flascam-slate)]">
    Format conseillé : image horizontale d’au moins 1600 × 700 pixels.
  </p>
</div>                

                <AdminInput
                  label="Ordre d’affichage"
                  type="number"
                  value={form.displayOrder}
                  onChange={(value) =>
                    updateField(
                      'displayOrder',
                      value,
                    )
                  }
                />
              </div>

              <label className="flex items-center gap-3 rounded-xl border border-[var(--flascam-border)] p-4 text-sm font-bold text-slate-800">
                <input
                  type="checkbox"
                  checked={form.isFeatured}
                  onChange={(event) =>
                    updateField(
                      'isFeatured',
                      event.target.checked,
                    )
                  }
                />
                Afficher cette association sur la page d’accueil
              </label>
            </FormSection>

            <FormSection title="Identifiants espace association">
              <div className="rounded-2xl bg-[#f8fbff] p-4 text-sm leading-6 text-[var(--flascam-slate)]">
                Ces identifiants permettent à l’association de se connecter à son propre espace admin.
                L’association ne pourra modifier que sa propre fiche et ses contenus.
              </div>

              <div className="grid gap-5 lg:grid-cols-2">
                <AdminInput
                  label="E-mail de connexion"
                  type="email"
                  value={form.adminEmail}
                  onChange={(value) =>
                    updateField(
                      'adminEmail',
                      value,
                    )
                  }
                  helper="Exemple : admin.casa@flascam.ma"
                />

                <AdminInput
                  label="Mot de passe"
                  type="password"
                  value={form.adminPassword}
                  onChange={(value) =>
                    updateField(
                      'adminPassword',
                      value,
                    )
                  }
                  helper={
                    selected
                      ? 'Laissez vide pour ne pas modifier le mot de passe.'
                      : 'Obligatoire si vous créez un compte association.'
                  }
                />

                <AdminInput
                  label="Prénom"
                  value={form.adminFirstName}
                  onChange={(value) =>
                    updateField(
                      'adminFirstName',
                      value,
                    )
                  }
                />

                <AdminInput
                  label="Nom"
                  value={form.adminLastName}
                  onChange={(value) =>
                    updateField(
                      'adminLastName',
                      value,
                    )
                  }
                />
              </div>
            </FormSection>

            <FormSection title="SEO">
              <AdminInput
                label="Titre SEO"
                value={form.seoTitle}
                onChange={(value) =>
                  updateField('seoTitle', value)
                }
              />

              <AdminTextarea
                label="Description SEO"
                value={form.seoDescription}
                onChange={(value) =>
                  updateField(
                    'seoDescription',
                    value,
                  )
                }
              />
            </FormSection>

            <div className="sticky bottom-0 -mx-6 -mb-6 border-t border-[var(--flascam-border)] bg-white p-4 sm:-mx-7 sm:-mb-7 sm:p-5">
              <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={closeModal}
disabled={
  saving ||
  logoUploading ||
  coverUploading ||
  uploadingLeaderRole !== null
}
                  className="inline-flex h-11 items-center justify-center rounded-xl border border-[var(--flascam-border)] px-5 text-sm font-bold text-slate-700 hover:border-slate-400 disabled:opacity-60"
                >
                  Annuler
                </button>

                <button
                  type="submit"
                  disabled={saving || logoUploading || coverUploading}
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[var(--flascam-blue)] px-5 text-sm font-bold text-white transition hover:bg-[var(--flascam-blue-dark)] disabled:opacity-60"
                >
                  {saving ? (
                    <Loader2
                      size={16}
                      className="animate-spin"
                    />
                  ) : (
                    <Save size={16} />
                  )}
                  Enregistrer
                </button>
              </div>
            </div>
          </form>
        </Modal>
      )}
    </main>
  );
}

function Modal({
  title,
  children,
  onClose,
  scrollRef,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  scrollRef: RefObject<HTMLDivElement | null>;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/50 p-0 sm:items-center sm:p-5">
      <div className="max-h-[96vh] w-full overflow-hidden rounded-t-[1.5rem] bg-white shadow-2xl sm:max-w-[min(96vw,90rem)] sm:rounded-[1.5rem]">
        <div className="flex items-center justify-between border-b border-[var(--flascam-border)] px-6 py-4 sm:px-7">
          <h2 className="text-lg font-extrabold text-slate-950">
            {title}
          </h2>

          <button
            type="button"
            onClick={onClose}
            className="grid size-10 place-items-center rounded-xl border border-[var(--flascam-border)] text-slate-600 hover:border-slate-400"
            aria-label="Fermer"
          >
            <X size={18} />
          </button>
        </div>

        <div
          ref={scrollRef}
          className="max-h-[calc(96vh-4.5rem)] overflow-y-auto px-5 py-5 sm:px-7 sm:py-7 lg:px-9"
        >
          {children}
        </div>
      </div>
    </div>
  );
}

function StatusButton({
  label,
  onClick,
  icon,
}: {
  label: string;
  onClick: () => void;
  icon?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex h-9 items-center justify-center gap-2 rounded-xl border border-[var(--flascam-border)] bg-white px-3 text-xs font-bold text-slate-700 transition hover:border-[var(--flascam-blue)] hover:text-[var(--flascam-blue)]"
    >
      {icon}
      {label}
    </button>
  );
}

function AssociationLeaderEditor({
  role,
  fullName,
  photoUrl,
  biography,
  message,
  isPublished,
  uploading,
  onFullNameChange,
  onBiographyChange,
  onMessageChange,
  onPublishedChange,
  onPhotoChange,
  onPhotoRemove,
}: {
  role: AssociationLeaderRole;
  fullName: string;
  photoUrl: string;
  biography: string;
  message: string;
  isPublished: boolean;
  uploading: boolean;

  onFullNameChange:
    (value: string) => void;

  onBiographyChange:
    (value: string) => void;

  onMessageChange:
    (value: string) => void;

  onPublishedChange:
    (value: boolean) => void;

  onPhotoChange:
    (
      event:
        ChangeEvent<HTMLInputElement>,
    ) => void;

  onPhotoRemove:
    () => void;
}) {
  const isPresident =
    role === 'PRESIDENT';

  const title =
    isPresident
      ? 'Président'
      : 'Secrétaire général';

  return (
    <article className="overflow-hidden rounded-2xl border border-[var(--flascam-border)] bg-[#f8fbfd]">
      <header className="flex flex-col gap-4 border-b border-[var(--flascam-border)] bg-white p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-xl bg-[#eaf4fb] text-[var(--flascam-blue)]">
            <UserRound
              size={20}
              aria-hidden="true"
            />
          </span>

          <div>
            <h3 className="font-extrabold text-slate-950">
              {title}
            </h3>

            <p className="mt-1 text-xs text-[var(--flascam-slate)]">
              {isPresident
                ? 'Biographie et mot du président'
                : 'Biographie du secrétaire général'}
            </p>
          </div>
        </div>

        <label className="inline-flex cursor-pointer items-center gap-3 text-sm font-bold text-slate-700">
          <input
            type="checkbox"
            checked={isPublished}
            onChange={(event) =>
              onPublishedChange(
                event.target.checked,
              )
            }
            className="size-4 accent-[var(--flascam-blue)]"
          />

          Afficher publiquement
        </label>
      </header>

      <div className="space-y-5 p-5">
        <div className="grid gap-5 sm:grid-cols-[9rem_minmax(0,1fr)]">
          <div>
            <div className="grid aspect-[4/5] w-full place-items-center overflow-hidden rounded-2xl border border-[var(--flascam-border)] bg-white">
              {photoUrl ? (
                <img
                  src={photoUrl}
                  alt={
                    fullName
                      ? `Photo de ${fullName}`
                      : `Photo du ${title.toLowerCase()}`
                  }
                  className="h-full w-full object-cover object-center"
                />
              ) : (
                <UserRound
                  size={42}
                  className="text-slate-300"
                  aria-hidden="true"
                />
              )}
            </div>

            <label
              className={`
                mt-3
                inline-flex
                min-h-10
                w-full
                cursor-pointer
                items-center
                justify-center
                gap-2
                rounded-xl
                border
                border-[var(--flascam-border)]
                bg-white
                px-3
                text-xs
                font-bold
                text-slate-700
                transition
                hover:border-[var(--flascam-blue)]
                hover:text-[var(--flascam-blue)]
                ${
                  uploading
                    ? 'pointer-events-none opacity-60'
                    : ''
                }
              `}
            >
              {uploading ? (
                <Loader2
                  size={15}
                  className="animate-spin"
                />
              ) : (
                <Upload size={15} />
              )}

              Importer

              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                className="hidden"
                disabled={uploading}
                onChange={onPhotoChange}
              />
            </label>

            {photoUrl && (
              <button
                type="button"
                onClick={onPhotoRemove}
                className="mt-2 min-h-9 w-full rounded-xl px-3 text-xs font-bold text-red-600 transition hover:bg-red-50"
              >
                Retirer la photo
              </button>
            )}
          </div>

          <AdminInput
            label="Nom complet"
            value={fullName}
            onChange={
              onFullNameChange
            }
            maxLength={180}
            helper={
              isPresident
                ? 'Nom et prénom du président.'
                : 'Nom et prénom du secrétaire général.'
            }
          />
        </div>

        <AdminTextarea
          label="Biographie"
          value={biography}
          onChange={
            onBiographyChange
          }
          maxLength={10_000}
          rows={7}
        />

        {isPresident && (
          <AdminTextarea
            label="Mot du président"
            value={message}
            onChange={
              onMessageChange
            }
            maxLength={10_000}
            rows={9}
          />
        )}

        <p className="text-xs leading-5 text-[var(--flascam-slate)]">
          Formats acceptés : JPG, PNG ou WebP. Utilisez
          idéalement une photo verticale au format 4:5 avec
          le visage centré.
        </p>
      </div>
    </article>
  );
}

function FormSection({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <section className="space-y-5">
      <h3 className="border-b border-[var(--flascam-border)] pb-3 text-sm font-extrabold uppercase tracking-[0.16em] text-[var(--flascam-blue)]">
        {title}
      </h3>

      {children}
    </section>
  );
}

function AdminInput({
  label,
  value,
  onChange,
  type = 'text',
  required = false,
  maxLength,
  helper,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
  maxLength?: number;
  helper?: string;
}) {
  return (
    <label className="block">
      <span className="text-sm font-bold text-slate-800">
        {label}
      </span>

      <input
        type={type}
        required={required}
        maxLength={maxLength}
        value={value}
        onChange={(event) =>
          onChange(event.target.value)
        }
        className="mt-2 h-11 w-full rounded-xl border border-[var(--flascam-border)] px-4 text-sm outline-none transition focus:border-[var(--flascam-blue)]"
      />

      {helper && (
        <span className="mt-1 block text-xs leading-5 text-[var(--flascam-slate)]">
          {helper}
        </span>
      )}
    </label>
  );
}

function AdminTextarea({
  label,
  value,
  onChange,
  maxLength,
  rows = 5,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  maxLength?: number;
  rows?: number;
}) {
  return (
    <label className="block">
      <span className="text-sm font-bold text-slate-800">
        {label}
      </span>

      <textarea
        value={value}
        maxLength={maxLength}
        rows={rows}
        onChange={(event) =>
          onChange(event.target.value)
        }
        className="mt-2 min-h-32 w-full resize-y rounded-xl border border-[var(--flascam-border)] px-4 py-3 text-sm leading-6 outline-none transition focus:border-[var(--flascam-blue)]"
      />

      {maxLength !== undefined && (
        <span className="mt-1 block text-right text-xs text-[var(--flascam-slate)]">
          {value.length.toLocaleString('fr-FR')}
          {' / '}
          {maxLength.toLocaleString('fr-FR')}
        </span>
      )}
    </label>
  );
}