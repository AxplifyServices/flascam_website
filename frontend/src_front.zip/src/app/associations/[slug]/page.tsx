import type {
  Metadata,
} from 'next';

import Link from 'next/link';

import {
  notFound,
} from 'next/navigation';

import {
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  ExternalLink,
  Globe,
  Mail,
  MapPin,
  Phone,
  UsersRound,
  ArrowDown,
  Play,
} from 'lucide-react';

import {
  PublicFooter,
} from '@/components/site/public-footer';

import {
  PublicHeader,
} from '@/components/site/public-header';

import {
  getPublicAssociationBySlug,
} from '@/lib/associations-api';

import {
  AdaptiveImage,
} from '@/components/site/adaptive-image';

import {
  VideoCard,
} from '@/components/site/video-card';

import {
  getPublicAssociationVideos,
} from '@/lib/videos-api';

import {
  VideoFirstFrame,
} from '@/components/site/video-first-frame';

type PageProps = {
  params: Promise<{
    slug: string;
  }>;
};

function formatDate(
  value?: string | null,
) {
  if (!value) {
    return null;
  }

  return new Intl.DateTimeFormat(
    'fr-MA',
    {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    },
  )
    .format(new Date(value))
    .replace('.', '')
    .toUpperCase();
}

function dayMonth(
  value?: string | null,
) {
  if (!value) {
    return {
      day: '',
      month: '',
    };
  }

  const date = new Date(value);

  return {
    day: new Intl.DateTimeFormat(
      'fr-MA',
      {
        day: '2-digit',
      },
    ).format(date),
    month: new Intl.DateTimeFormat(
      'fr-MA',
      {
        month: 'short',
      },
    )
      .format(date)
      .replace('.', '')
      .toUpperCase(),
  };
}

function normalizeUrl(
  value?: string | null,
) {
  if (!value) {
    return null;
  }

  if (
    value.startsWith('http://') ||
    value.startsWith('https://')
  ) {
    return value;
  }

  return `https://${value}`;
}

function AssociationLogo({
  name,
  logoText,
  logoUrl,
}: {
  name: string;
  logoText?: string | null;
  logoUrl?: string | null;
}) {
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={`Logo ${name}`}
        className="h-full w-full object-contain"
      />
    );
  }

  return (
    <span className="text-2xl font-black text-white">
      {logoText || name.slice(0, 2).toUpperCase()}
    </span>
  );
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const {
    slug,
  } = await params;

  const association =
    await getPublicAssociationBySlug(slug);

  if (!association) {
    return {
      title: 'Association introuvable',
    };
  }

  const title =
    association.seoTitle ||
    association.name;

  const description =
    association.seoDescription ||
    association.presentation ||
    `Page officielle de ${association.name}, association régionale affiliée à FLASCAM.`;

  return {
    title,
    description,
    alternates: {
      canonical: `/associations/${association.slug}`,
    },
    openGraph: {
      title,
      description,
      type: 'article',
      locale: 'fr_MA',
images:
  association.coverImageUrl || association.logoUrl
    ? [
        {
          url:
            association.coverImageUrl ||
            association.logoUrl ||
            '',
          alt: association.name,
        },
      ]
    : undefined,
    },
  };
}

export default async function AssociationDetailPage({
  params,
}: PageProps) {
  const {
    slug,
  } = await params;

  const association =
    await getPublicAssociationBySlug(slug);

  if (!association) {
    notFound();
  }

  const website =
    normalizeUrl(association.websiteUrl);

const actualities =
  association.actualities ?? [];

const latestActualities =
  actualities.slice(
    0,
    3,
  );

const additionalActualities =
  actualities.slice(
    3,
  );

const events =
  association.events ?? [];

  const photos =
    association.photos ?? [];

const associationVideosResponse =
  await getPublicAssociationVideos(
    association.slug,
    {
      page:
        1,

      limit:
        4,
    },
  );

const videos =
  associationVideosResponse.items;

const leaders =
  association.leaders ?? [];

const president =
  leaders.find(
    (leader) =>
      leader.role === 'PRESIDENT',
  );

const secretaryGeneral =
  leaders.find(
    (leader) =>
      leader.role ===
      'SECRETARY_GENERAL',
  );

const visibleLeaders = [
  president,
  secretaryGeneral,
].filter(
  (
    leader,
  ): leader is NonNullable<
    typeof leader
  > =>
    Boolean(leader),
);

const presidentMessage =
  president?.message?.trim() ?? '';    

  const socialLinks = [
    {
      label: 'Facebook',
      href: normalizeUrl(
        association.facebookUrl,
      ),
    },
    {
      label: 'Instagram',
      href: normalizeUrl(
        association.instagramUrl,
      ),
    },
    {
      label: 'LinkedIn',
      href: normalizeUrl(
        association.linkedinUrl,
      ),
    },
    {
      label: 'YouTube',
      href: normalizeUrl(
        association.youtubeUrl,
      ),
    },
  ].filter((item) => item.href);

  return (
    <>
      <PublicHeader />

      <main>
<section
  className="
    relative
    h-[280px]
    overflow-hidden
    bg-gradient-to-br
    from-[#07355d]
    via-[#0a487b]
    to-[#0f5f9f]
    sm:h-[360px]
    lg:h-[430px]
  "
>
  {association.coverImageUrl ? (
<AdaptiveImage
  src={
    association.coverImageUrl
  }
  alt={`Bannière de ${association.name}`}
  loading="eager"
  fetchPriority="high"
  fit="cover"
  position="center"
  imageClassName="
    transition
    duration-700
  "
/>
  ) : (
    <>
      <div
        aria-hidden="true"
        className="
          pointer-events-none
          absolute
          inset-0
          opacity-[0.12]
        "
        style={{
          backgroundImage:
            'radial-gradient(circle, rgba(255,255,255,0.8) 1px, transparent 1px)',
          backgroundSize:
            '22px 22px',
        }}
      />

      <div
        aria-hidden="true"
        className="
          pointer-events-none
          absolute
          -right-36
          -top-48
          h-[32rem]
          w-[32rem]
          rounded-full
          border
          border-white/10
        "
      />
    </>
  )}

  <div
    aria-hidden="true"
    className="
      pointer-events-none
      absolute
      inset-x-0
      bottom-0
      z-20
      h-20
      bg-gradient-to-t
      from-[#07355d]/40
      to-transparent
    "
  />
</section>

<section className="border-b border-[#dbe5ef] bg-white">
  <div className="site-container py-8 sm:py-10">
    <nav className="flex flex-wrap items-center gap-2 text-sm font-medium text-[#536273]">
      <Link
        href="/"
        className="transition hover:text-[#0f5f9f]"
      >
        Accueil
      </Link>

      <span>/</span>

      <Link
        href="/associations"
        className="transition hover:text-[#0f5f9f]"
      >
        Associations
      </Link>

      <span>/</span>

      <span className="font-semibold text-[#07355d]">
        {association.name}
      </span>
    </nav>

    <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
        <div
          className={`
            grid
            h-28
            w-28
            shrink-0
            place-items-center
            overflow-hidden
            rounded-xl
            border
            border-[#dbe5ef]
            p-3
            shadow-[0_14px_35px_rgba(7,53,93,0.12)]
            sm:h-32
            sm:w-32
            ${
              association.logoUrl
                ? 'bg-white'
                : 'bg-[#07355d]'
            }
          `}
        >
          <AssociationLogo
            name={association.name}
            logoText={association.logoText}
            logoUrl={association.logoUrl}
          />
        </div>

        <div>
          <p className="flex items-center gap-3 text-xs font-extrabold uppercase tracking-[0.18em] text-[#c96f4a]">
            <span className="h-[3px] w-8 bg-[#c96f4a]" />
            Association régionale
          </p>

          <h1 className="mt-4 max-w-4xl text-4xl font-extrabold leading-[1.08] tracking-[-0.045em] text-[#101820] sm:text-5xl">
            {association.name}
          </h1>

          <div className="mt-5 flex flex-wrap gap-x-6 gap-y-3 text-sm font-medium text-[#536273]">
            <span className="inline-flex items-center gap-2">
              <MapPin
                size={17}
                className="text-[#c96f4a]"
                aria-hidden="true"
              />

              {association.city
                ? `${association.city} · ${association.region}`
                : association.region}
            </span>

            {association.memberCount !== null &&
              association.memberCount !== undefined && (
                <span className="inline-flex items-center gap-2">
                  <UsersRound
                    size={17}
                    className="text-[#0f5f9f]"
                    aria-hidden="true"
                  />

                  {association.memberCount} loueurs membres
                </span>
              )}

            {association.affiliatedSinceYear && (
              <span className="inline-flex items-center gap-2">
                <CalendarDays
                  size={17}
                  className="text-[#0f5f9f]"
                  aria-hidden="true"
                />

                Affiliée depuis {association.affiliatedSinceYear}
              </span>
            )}
          </div>
        </div>
      </div>

<Link
  href={`/contact?association=${encodeURIComponent(
    association.slug,
  )}`}
  className="inline-flex min-h-12 items-center justify-center gap-3 rounded-md bg-[#c96f4a] px-6 text-sm font-extrabold !text-white transition hover:bg-[#a95235] hover:!text-white focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#c96f4a]/25"
>
  Contacter l’association

  <ArrowRight
    size={17}
    aria-hidden="true"
  />
</Link>
    </div>
  </div>
</section>

        <section className="relative overflow-hidden bg-[#f5f9fc] py-12 sm:py-16 lg:py-20">
          <div
            aria-hidden="true"
            className="absolute -left-40 top-20 h-80 w-80 rounded-full bg-[#0f5f9f]/[0.05] blur-3xl"
          />

          <div className="site-container relative">
            <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_23rem] xl:grid-cols-[minmax(0,1fr)_25rem]">
              <div className="min-w-0 space-y-14">
              <section>
                <div className="flex items-center gap-3">
                  <span className="h-[3px] w-10 bg-[#c96f4a]" />

                  <h2 className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#0f5f9f]">
                    Présentation
                  </h2>
                </div>

                <div className="mt-6 border-l-4 border-[#0f5f9f] bg-white p-6 sm:p-8">
                  <div className="space-y-5 text-base leading-8 text-[#536273]">
                    {association.presentation ? (
                      association.presentation
                        .split('\n')
                        .filter(Boolean)
                        .map((paragraph) => (
                          <p key={paragraph}>
                            {paragraph}
                          </p>
                        ))
                    ) : (
                      <p>
                        La présentation de cette association sera bientôt disponible.
                      </p>
                    )}
                  </div>
                </div>
              </section>

{president &&
  presidentMessage && (
    <section>
      <div className="flex items-center gap-3">
        <span className="h-[3px] w-10 bg-[#c96f4a]" />

        <h2 className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#0f5f9f]">
          Mot du président
        </h2>
      </div>

      <article className="relative mt-6 overflow-hidden border border-[#dbe5ef] bg-white">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-[#0f5f9f]/[0.06]"
        />

        <div className="relative grid gap-7 p-6 sm:p-8 md:grid-cols-[11rem_minmax(0,1fr)] md:items-start">
          <div className="mx-auto w-full max-w-44 md:mx-0">
            <div className="aspect-[4/5] overflow-hidden border border-[#dbe5ef] bg-[#eaf5ff]">
              {president.photoUrl ? (
                <img
                  src={
                    president.photoUrl
                  }
                  alt={`Portrait de ${president.fullName}`}
                  className="h-full w-full object-cover object-center"
                />
              ) : (
                <div className="grid h-full place-items-center">
                  <UsersRound
                    size={48}
                    className="text-[#0f5f9f]/35"
                    aria-hidden="true"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="min-w-0">
            <span
              aria-hidden="true"
              className="block h-12 text-6xl font-black leading-none text-[#c96f4a]/25"
            >
              “
            </span>

            <div className="space-y-5 text-base leading-8 text-[#536273]">
              {presidentMessage
                .split('\n')
                .map(
                  (paragraph) =>
                    paragraph.trim(),
                )
                .filter(Boolean)
                .map(
                  (
                    paragraph,
                    index,
                  ) => (
                    <p
                      key={`${index}-${paragraph}`}
                    >
                      {paragraph}
                    </p>
                  ),
                )}
            </div>

            <footer className="mt-7 border-t border-[#dbe5ef] pt-5">
              <p className="text-lg font-extrabold text-[#07355d]">
                {president.fullName}
              </p>

              <p className="mt-1 text-xs font-extrabold uppercase tracking-[0.14em] text-[#c96f4a]">
                Président de l’association
              </p>
            </footer>
          </div>
        </div>
      </article>
    </section>
  )}


<section>
  <div className="flex items-center justify-between gap-5 border-b border-[#dbe5ef] pb-5">
    <div className="flex items-center gap-3">
      <span className="h-[3px] w-10 bg-[#c96f4a]" />

      <h2 className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#0f5f9f]">
        Actualités de l’association
      </h2>
    </div>

    {actualities.length > 0 && (
      <span className="shrink-0 text-xs font-bold text-[#536273]">
        {actualities.length}{' '}
        {actualities.length > 1
          ? 'publications'
          : 'publication'}
      </span>
    )}
  </div>

  {actualities.length === 0 ? (
    <div className="mt-6 border border-dashed border-[#b9c9d8] bg-white p-6 text-sm leading-7 text-[#536273]">
      Aucune actualité publiée pour le moment.
    </div>
  ) : (
    <div className="mt-6">
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {latestActualities.map(
          (
            post,
          ) => (
            <Link
              key={
                post.id
              }
              href={`/actualites/${post.slug}`}
              className="group flex min-w-0 flex-col overflow-hidden border border-[#dbe5ef] bg-white transition duration-300 hover:-translate-y-1 hover:border-[#c96f4a]/50 hover:shadow-[0_22px_55px_rgba(7,53,93,0.1)] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#0f5f9f]/20"
            >
              <div className="relative h-44 overflow-hidden bg-[#eaf5ff] sm:h-48">
{post.coverUrl &&
post.coverMediaType ===
  'VIDEO' ? (
  <>
    <VideoFirstFrame
      src={
        post.coverUrl
      }
      title={
        post.coverAltText ||
        post.title
      }
      className="
        transition
        duration-500
        group-hover:scale-105
      "
    />

    <span
      className="
        pointer-events-none
        absolute
        inset-0
        grid
        place-items-center
        bg-slate-950/15
      "
    >
      <span
        className="
          grid
          size-12
          place-items-center
          rounded-full
          bg-white/95
          text-[#07355d]
          shadow-xl
        "
      >
        <Play
          size={
            19
          }
          fill="currentColor"
          aria-hidden="true"
        />
      </span>
    </span>
  </>
) : post.coverUrl ? (
  <AdaptiveImage
    src={
      post.coverUrl
    }
    alt={
      post.coverAltText ||
      post.title
    }
    fit="cover"
    position="center"
    imageClassName="
      transition
      duration-500
      group-hover:scale-105
    "
  />
) : (
  <div className="grid h-full place-items-center px-5 text-center text-sm font-bold text-[#0f5f9f]">
    Actualité de l’association
  </div>
)}

                <div className="absolute bottom-0 left-0 h-1 w-20 bg-[#c96f4a] transition-all duration-300 group-hover:w-full" />
              </div>

              <div className="flex flex-1 flex-col p-5 sm:p-6">
                <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-[#c96f4a]">
                  {formatDate(
                    post.publishedAt ||
                      post.createdAt,
                  )}
                </p>

                <h3 className="mt-3 line-clamp-2 text-lg font-extrabold leading-tight text-[#07355d] sm:text-xl">
                  {post.title}
                </h3>

                {post.excerpt && (
                  <p className="mt-3 line-clamp-3 text-sm leading-7 text-[#536273]">
                    {post.excerpt}
                  </p>
                )}

                <span className="mt-auto inline-flex items-center gap-2 pt-5 text-sm font-extrabold text-[#0f5f9f]">
                  Lire l’actualité

                  <ArrowRight
                    size={
                      16
                    }
                    aria-hidden="true"
                    className="transition-transform group-hover:translate-x-1"
                  />
                </span>
              </div>
            </Link>
          ),
        )}
      </div>

      {additionalActualities.length > 0 && (
        <details className="group/more mt-8">
          <summary className="mx-auto flex min-h-11 w-fit cursor-pointer list-none items-center justify-center gap-2 rounded-md border border-[#0f5f9f] bg-white px-5 py-3 text-sm font-extrabold text-[#0f5f9f] transition hover:bg-[#eaf5ff] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#0f5f9f]/20 [&::-webkit-details-marker]:hidden">
            <span className="group-open/more:hidden">
              Afficher plus d’actualités
            </span>

            <span className="hidden group-open/more:inline">
              Réduire les actualités
            </span>

            <ArrowDown
              size={
                17
              }
              aria-hidden="true"
              className="transition-transform duration-300 group-open/more:rotate-180"
            />
          </summary>

          <div className="mt-6 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {additionalActualities.map(
              (
                post,
              ) => (
                <Link
                  key={
                    post.id
                  }
                  href={`/actualites/${post.slug}`}
                  className="group flex min-w-0 flex-col overflow-hidden border border-[#dbe5ef] bg-white transition duration-300 hover:-translate-y-1 hover:border-[#c96f4a]/50 hover:shadow-[0_22px_55px_rgba(7,53,93,0.1)] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#0f5f9f]/20"
                >
                  <div className="relative h-44 overflow-hidden bg-[#eaf5ff] sm:h-48">
{post.coverUrl &&
post.coverMediaType ===
  'VIDEO' ? (
  <>
    <VideoFirstFrame
      src={
        post.coverUrl
      }
      title={
        post.coverAltText ||
        post.title
      }
      className="
        transition
        duration-500
        group-hover:scale-105
      "
    />

    <span
      className="
        pointer-events-none
        absolute
        inset-0
        grid
        place-items-center
        bg-slate-950/15
      "
    >
      <span
        className="
          grid
          size-12
          place-items-center
          rounded-full
          bg-white/95
          text-[#07355d]
          shadow-xl
        "
      >
        <Play
          size={
            19
          }
          fill="currentColor"
          aria-hidden="true"
        />
      </span>
    </span>
  </>
) : post.coverUrl ? (
  <AdaptiveImage
    src={
      post.coverUrl
    }
    alt={
      post.coverAltText ||
      post.title
    }
    fit="cover"
    position="center"
    imageClassName="
      transition
      duration-500
      group-hover:scale-105
    "
  />
) : (
  <div className="grid h-full place-items-center px-5 text-center text-sm font-bold text-[#0f5f9f]">
    Actualité de l’association
  </div>
)}

                    <div className="absolute bottom-0 left-0 h-1 w-20 bg-[#c96f4a] transition-all duration-300 group-hover:w-full" />
                  </div>

                  <div className="flex flex-1 flex-col p-5 sm:p-6">
                    <p className="text-xs font-extrabold uppercase tracking-[0.12em] text-[#c96f4a]">
                      {formatDate(
                        post.publishedAt ||
                          post.createdAt,
                      )}
                    </p>

                    <h3 className="mt-3 line-clamp-2 text-lg font-extrabold leading-tight text-[#07355d] sm:text-xl">
                      {post.title}
                    </h3>

                    {post.excerpt && (
                      <p className="mt-3 line-clamp-3 text-sm leading-7 text-[#536273]">
                        {post.excerpt}
                      </p>
                    )}

                    <span className="mt-auto inline-flex items-center gap-2 pt-5 text-sm font-extrabold text-[#0f5f9f]">
                      Lire l’actualité

                      <ArrowRight
                        size={
                          16
                        }
                        aria-hidden="true"
                        className="transition-transform group-hover:translate-x-1"
                      />
                    </span>
                  </div>
                </Link>
              ),
            )}
          </div>
        </details>
      )}
    </div>
  )}
</section>

<section>
  <div
    className="
      flex
      flex-wrap
      items-center
      justify-between
      gap-4
      border-b
      border-[#dbe5ef]
      pb-5
    "
  >
    <div className="flex items-center gap-3">
      <span className="h-[3px] w-10 bg-[#c96f4a]" />

      <h2 className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#0f5f9f]">
        Vidéos de l’association
      </h2>
    </div>

    {videos.length >
      0 && (
      <Link
        href={`/videotheque?association=${encodeURIComponent(
          association.slug,
        )}`}
        className="
          inline-flex
          items-center
          gap-2
          text-sm
          font-extrabold
          text-[#0f5f9f]
          transition
          hover:text-[#07355d]
        "
      >
        Voir toutes les vidéos

        <ArrowRight
          size={16}
          aria-hidden="true"
        />
      </Link>
    )}
  </div>

  {videos.length ===
  0 ? (
    <div className="mt-6 border border-dashed border-[#b9c9d8] bg-white p-6 text-sm leading-7 text-[#536273]">
      Aucune vidéo publiée pour le moment.
    </div>
  ) : (
    <div
      className="
        mt-6
        grid
        gap-6
        md:grid-cols-2
      "
    >
      {videos.map(
        (
          video,
        ) => (
          <VideoCard
            key={
              video.id
            }
            video={
              video
            }
          />
        ),
      )}
    </div>
  )}
</section>
            </div>

            <aside className="space-y-6 lg:sticky lg:top-28 lg:self-start">
              <section className="border-t-4 border-[#c96f4a] bg-[#07355d] p-6 text-white sm:p-7">
                <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#f0a27f]">
                  Coordonnées
                </p>

                <div className="mt-5 divide-y divide-white/15 text-sm text-white/75">
                  {association.address && (
                    <p className="flex gap-3 py-4">
                      <MapPin
                        size={17}
                        className="shrink-0 text-[#f0a27f]"
                        aria-hidden="true"
                      />

                      {association.address}
                    </p>
                  )}

                  {association.phone && (
                    <a
                      href={`tel:${association.phone}`}
                      className="flex gap-3 py-4 transition hover:text-white"
                    >
                      <Phone
                        size={17}
                        className="shrink-0 text-[#f0a27f]"
                        aria-hidden="true"
                      />

                      {association.phone}
                    </a>
                  )}

                  {association.email && (
                    <a
                      href={`mailto:${association.email}`}
                      className="flex gap-3 py-4 transition hover:text-white"
                    >
                      <Mail
                        size={17}
                        className="shrink-0 text-[#f0a27f]"
                        aria-hidden="true"
                      />

                      {association.email}
                    </a>
                  )}

                  {website && (
                    <a
                      href={website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex gap-3 py-4 transition hover:text-white"
                    >
                      <Globe
                        size={17}
                        className="shrink-0 text-[#f0a27f]"
                        aria-hidden="true"
                      />

                      {association.websiteUrl}
                    </a>
                  )}
                </div>

                {socialLinks.length > 0 && (
                  <div className="mt-6 flex flex-wrap gap-2 border-t border-white/15 pt-5">
                    {socialLinks.map((item) => (
                      <a
                        key={item.label}
                        href={item.href || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 border border-white/20 px-3 py-2 text-xs font-bold text-white/75 transition hover:border-[#c96f4a] hover:bg-[#c96f4a] hover:text-white"
                      >
                        {item.label}

                        <ExternalLink
                          size={13}
                          aria-hidden="true"
                        />
                      </a>
                    ))}
                  </div>
                )}
              </section>

              <section className="border border-[#dbe5ef] bg-white p-6 sm:p-7">
                <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#0f5f9f]">
                  Agenda & événements
                </p>

                {events.length === 0 ? (
                  <p className="mt-5 text-sm leading-7 text-[#536273]">
                    Aucun événement à venir publié pour le moment.
                  </p>
                ) : (
                  <div className="mt-5 divide-y divide-[#dbe5ef]">
                    {events.map((event) => {
                      const date =
                        dayMonth(event.eventStartAt);

                      return (
<Link
  key={
    event.id
  }
  href={`/actualites/${event.slug}`}
  className="group grid grid-cols-[3.5rem_1fr] gap-4 py-5 transition first:pt-0 last:pb-0 hover:bg-[#f5f9fc] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0f5f9f]/30"
>
                          <div className="border-r border-[#dbe5ef] pr-4 text-center">
                            <p className="text-2xl font-black text-[#07355d]">
                              {date.day}
                            </p>

                            <p className="text-xs font-extrabold uppercase text-[#c96f4a]">
                              {date.month}
                            </p>
                          </div>

<div className="min-w-0">
  <h3 className="font-extrabold leading-snug text-[#07355d] transition group-hover:text-[#0f5f9f]">
    {event.title}
  </h3>

  {event.eventLocation && (
    <p className="mt-2 flex items-start gap-2 text-sm leading-6 text-[#536273]">
      <MapPin
        size={
          14
        }
        className="mt-1 shrink-0 text-[#c96f4a]"
        aria-hidden="true"
      />

      <span>
        {event.eventLocation}
      </span>
    </p>
  )}

  <span className="mt-3 inline-flex items-center gap-1 text-xs font-extrabold text-[#0f5f9f]">
    Voir l’événement

    <ArrowRight
      size={
        13
      }
      aria-hidden="true"
      className="transition-transform group-hover:translate-x-1"
    />
  </span>
</div>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </section>

              <Link
                href="/associations"
                className="inline-flex items-center gap-2 text-sm font-extrabold text-[#0f5f9f] transition hover:text-[#07355d]"
              >
                <ArrowLeft
                  size={16}
                  aria-hidden="true"
                />

                Retour aux associations
              </Link>
            </aside>
          </div>

            {visibleLeaders.length > 0 && (
              <section className="mt-14 sm:mt-16 lg:mt-20">
                <div className="flex items-center gap-3 border-b border-[#dbe5ef] pb-5">
                  <span className="h-[3px] w-10 bg-[#c96f4a]" />

                  <h2 className="text-xs font-extrabold uppercase tracking-[0.18em] text-[#0f5f9f]">
                    Équipe dirigeante
                  </h2>
                </div>

                <div className="mt-8 space-y-8">
                  {visibleLeaders.map((leader) => {
                    const isPresident =
                      leader.role === 'PRESIDENT';

                    const biography =
                      leader.biography?.trim() ?? '';

                    return (
                      <article
                        key={leader.id}
                        className="group overflow-hidden border border-[#dbe5ef] bg-white transition duration-300 hover:-translate-y-1 hover:border-[#0f5f9f]/35 hover:shadow-[0_24px_65px_rgba(7,53,93,0.1)]"
                      >
                        <div className="grid lg:grid-cols-[25rem_minmax(0,1fr)] xl:grid-cols-[30rem_minmax(0,1fr)]">
                          <div className="relative min-h-[28rem] overflow-hidden bg-[#eaf5ff] sm:min-h-[34rem] lg:min-h-[40rem]">
                            {leader.photoUrl ? (
                              <img
                                src={leader.photoUrl}
                                alt={`Portrait de ${leader.fullName}`}
                                className="absolute inset-0 h-full w-full object-cover object-center transition duration-500 group-hover:scale-[1.025]"
                              />
                            ) : (
                              <div className="grid h-full min-h-[34rem] place-items-center">
                                <UsersRound
                                  size={68}
                                  className="text-[#0f5f9f]/35"
                                  aria-hidden="true"
                                />
                              </div>
                            )}
                          </div>

                          <div className="min-w-0 p-6 sm:p-9 lg:p-12 xl:p-14">
                            <p className="text-sm font-extrabold uppercase tracking-[0.16em] text-[#c96f4a]">
                              {isPresident
                                ? 'Président'
                                : 'Secrétaire général'}
                            </p>

                            <h3 className="mt-4 text-3xl font-extrabold leading-tight tracking-[-0.025em] text-[#07355d] sm:text-4xl">
                              {leader.fullName}
                            </h3>

                            {biography ? (
                              <div className="mt-8 max-w-none space-y-6 text-base leading-8 text-[#536273] sm:text-lg sm:leading-9">
                                {biography
                                  .split('\n')
                                  .map((paragraph) =>
                                    paragraph.trim(),
                                  )
                                  .filter(Boolean)
                                  .map(
                                    (
                                      paragraph,
                                      index,
                                    ) => (
                                      <p
                                        key={`${index}-${paragraph}`}
                                      >
                                        {paragraph}
                                      </p>
                                    ),
                                  )}
                              </div>
                            ) : (
                              <p className="mt-8 text-base leading-8 text-[#536273]">
                                La biographie de ce responsable sera bientôt disponible.
                              </p>
                            )}
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              </section>
            )}
          </div>
        </section>
      </main>

      <PublicFooter />
    </>
  );
}